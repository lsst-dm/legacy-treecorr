
NN: Count-count correlations
----------------------------

.. autoclass:: treecorr.NNCorrelation
    :members:
    :show-inheritance:


