Catalogs
========

The Catalog class
-----------------

.. autoclass:: treecorr.Catalog
    :members:

Other utilities related to catalogs
-----------------------------------

.. automodule:: treecorr.catalog
    :members:
    :exclude-members: Catalog

