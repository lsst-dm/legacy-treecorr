
NK: Count-kappa correlations
----------------------------

.. autoclass:: treecorr.NKCorrelation
    :members:
    :show-inheritance:


