Celestial Coordinates
=====================

The CelestialCoord class
------------------------

.. autoclass:: treecorr.CelestialCoord
    :members:

Angular units
-------------

.. automodule:: treecorr.celestial
    :members:
    :exclude-members: CelestialCoord

