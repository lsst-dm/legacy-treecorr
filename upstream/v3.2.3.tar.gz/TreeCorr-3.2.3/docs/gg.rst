
GG: Shear-shear correlations
----------------------------

.. autoclass:: treecorr.GGCorrelation
    :members:
    :show-inheritance:


