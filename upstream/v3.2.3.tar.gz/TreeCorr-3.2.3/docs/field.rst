Fields
======

NField
------

.. autoclass:: treecorr.NField
    :members:

GField
------

.. autoclass:: treecorr.GField
    :members:

KField
------

.. autoclass:: treecorr.KField
    :members:

NSimpleField
------------

.. autoclass:: treecorr.NSimpleField
    :members:

GSimpleField
------------

.. autoclass:: treecorr.GSimpleField
    :members:

KSimpleField
------------

.. autoclass:: treecorr.KSimpleField
    :members:

