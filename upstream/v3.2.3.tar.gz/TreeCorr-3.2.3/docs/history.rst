
Previous History
================

`Changes from version 3.0 to 3.1 
<https://github.com/rmjarvis/TreeCorr/blob/releases/3.1/CHANGELOG.rst>`_

`Changes from version 2.6 to 3.0 
<https://github.com/rmjarvis/TreeCorr/blob/releases/3.0/CHANGELOG.md>`_
