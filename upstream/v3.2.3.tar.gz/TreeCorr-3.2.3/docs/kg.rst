
KG: Kappa-shear correlations
----------------------------

.. autoclass:: treecorr.KGCorrelation
    :members:
    :show-inheritance:


