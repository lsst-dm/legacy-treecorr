
GGG: Shear-shear-shear correlations
-----------------------------------

.. autoclass:: treecorr.GGGCorrelation
    :members:
    :show-inheritance:


